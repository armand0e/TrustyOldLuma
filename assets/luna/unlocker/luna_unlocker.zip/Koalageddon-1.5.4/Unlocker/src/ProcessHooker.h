#pragma once

namespace ProcessHooker
{

void init();
void shutdown();

}
