#pragma once

namespace DLLMonitor
{

void init();
void shutdown();

}
