#pragma once

#include "hook_util.h"

int UPLAY_USER_IsOwned(int aUplayId);
