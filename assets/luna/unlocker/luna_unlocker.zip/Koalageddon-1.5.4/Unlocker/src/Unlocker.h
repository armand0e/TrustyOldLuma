#pragma once
#include "framework.h"

namespace Unlocker
{

void init(HMODULE hModule);
void shutdown();

}
