#pragma once

namespace UpdateChecker
{

void checkForUpdates();

}