#pragma once

extern HMODULE hOriginal;

/*
#pragma comment(linker, "/export:GetFileVersionInfoA=version_o.GetFileVersionInfoA")
#pragma comment(linker, "/export:GetFileVersionInfoByHandle=version_o.GetFileVersionInfoByHandle")
#pragma comment(linker, "/export:GetFileVersionInfoExA=version_o.GetFileVersionInfoExA")
#pragma comment(linker, "/export:GetFileVersionInfoExW=version_o.GetFileVersionInfoExW")
#pragma comment(linker, "/export:GetFileVersionInfoSizeA=version_o.GetFileVersionInfoSizeA")
#pragma comment(linker, "/export:GetFileVersionInfoSizeExA=version_o.GetFileVersionInfoSizeExA")
#pragma comment(linker, "/export:GetFileVersionInfoSizeExW=version_o.GetFileVersionInfoSizeExW")
#pragma comment(linker, "/export:GetFileVersionInfoSizeW=version_o.GetFileVersionInfoSizeW")
#pragma comment(linker, "/export:GetFileVersionInfoW=version_o.GetFileVersionInfoW")
#pragma comment(linker, "/export:VerFindFileA=version_o.VerFindFileA")
#pragma comment(linker, "/export:VerFindFileW=version_o.VerFindFileW")
#pragma comment(linker, "/export:VerInstallFileA=version_o.VerInstallFileA")
#pragma comment(linker, "/export:VerInstallFileW=version_o.VerInstallFileW")
#pragma comment(linker, "/export:VerLanguageNameA=version_o.VerLanguageNameA")
#pragma comment(linker, "/export:VerLanguageNameW=version_o.VerLanguageNameW")
#pragma comment(linker, "/export:VerQueryValueA=version_o.VerQueryValueA")
#pragma comment(linker, "/export:VerQueryValueW=version_o.VerQueryValueW")
*/